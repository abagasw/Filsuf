package com.owa.filsufbarat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.Objects;

public class detailfilsuf extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailfilsuf);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        Filsuf filsufditerima = getIntent().getParcelableExtra("key");

        ImageView gambar = (ImageView)findViewById(R.id.img_item_photo);
        TextView name = (TextView)findViewById(R.id.tv_item_name);
        TextView remarks = (TextView)findViewById(R.id.tv_item_remarks);
        TextView deskripsi = (TextView)findViewById(R.id.content_detail);
        TextView lahir = (TextView)findViewById(R.id.content_lahir);
        TextView wafat = (TextView)findViewById(R.id.content_wafat);

        Glide.with(this)
                .load(filsufditerima.getPhoto())
                .override(350,550).into(gambar);
        name.setText(filsufditerima.getName());
        remarks.setText(filsufditerima.getRemarks());
        deskripsi.setText(filsufditerima.getDeskripsi());
        lahir.setText(filsufditerima.getLahir());
        wafat.setText(filsufditerima.getWafat());

        Log.i("photo", filsufditerima.getPhoto());
        Log.i("deskripsi", filsufditerima.getDeskripsi());
    }


}
