package com.owa.filsufbarat;

import java.util.ArrayList;

public class FilsufData {
    public static String[][] data = new String[][]{
            {
                    "Socrates",
                    "Filsuf Pertama",
                    "https://upload.wikimedia.org/wikipedia/commons/a/a4/Socrates_Louvre.jpg",
                    " Socrates lahir di Athena, dan merupakan generasi pertama dari tiga ahli filsafat besar dari Yunani selain Plato dan Aristoteles. ",
                    "469 / 470 SM di Deme Alopece,Athena",
                    "399 SM di Athena"
            },
            {
                    "Plato",
                    "Filsuf Ke-2",
                    "https://upload.wikimedia.org/wikipedia/commons/4/4a/Plato-raphael.jpg",
                    "Plato adalah adalah seorang filsuf dan matematikawan Yunani, penulis philosophical dialogues dan pendiri dari Akademi Platonik di Athena, sekolah tingkat tinggi pertama di dunia barat.",
                    "427 SM di Athena",
                    "347 SM di Athena"},
            {
                    "Aristoteles",
                    "Filsuf Ke-3",
                    "https://upload.wikimedia.org/wikipedia/commons/a/ae/Aristotle_Altemps_Inv8575.jpg", "Aristoteles adalah  seorang filsuf Yunani, murid dari Plato dan guru dari Alexander Agung. ",
                    "384 SM Stagira, Chalcidice",
                    "322 SM Euboea"},
            {
                    "Thomas Aquinas",
                    "Filsuf Pasca Aristoteles",
                    "https://upload.wikimedia.org/wikipedia/commons/d/d1/Carlo_Crivelli_007.jpg",
                    "Thomas Aquinas adalah seorang yuris, teolog, dan filsuf yang sangat berpengaruh dalam tradisi skolastisisme, yang di dalamnya ia juga dikenal sebagai Doctor Angelicus dan Doctor Communis.",
                    "1225 di Roccasecca, Kerajaan Sisilia",
                    "7 Maret 1274 di Fossanova, Negara Gereja"}
    };
    public static ArrayList<Filsuf> getListData(){
        Filsuf filsuf = null;
        ArrayList<Filsuf> list = new ArrayList<>();
        for (String[] aData : data) {
            filsuf = new Filsuf();
            filsuf.setName(aData[0]);
            filsuf.setRemarks(aData[1]);
            filsuf.setPhoto(aData[2]);
            filsuf.setDeskripsi(aData[3]);
            filsuf.setLahir(aData[4]);
            filsuf.setWafat(aData[5]);

            list.add(filsuf);
        }

        return list;
    }

}

